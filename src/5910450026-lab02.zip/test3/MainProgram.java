package test3;
import java.util.Scanner;
public class MainProgram {
    public static void main ( String[] args){
        int p;
        Scanner sc = new Scanner(System.in);
        p = sc.nextInt();
        Game num = new Game(p);
       // System.out.println(num.checkTarget(45));
        num.checkTarget(p);
    }

}
