package test3;

public class Game {
    private int target=72;
    private int player;

    public Game(int player) {
        //this.target = target;
        this.player = player;
    }

    public int getTarget() {
        return target;
    }

    public int getPlayer() {
        return player;
    }

    public void  checkTarget( int player){
        if ( player == target){
            System.out.println("Congratulation");
        }
        else if ( player > target){
            System.out.println("too high");
        }
        else {
            System.out.println("too low");
        }
    }

}
