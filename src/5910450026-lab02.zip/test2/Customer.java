package test2;

public class Customer {
    private int customerSpent;
    private int stamps;


    public Customer( int customerSpent){

        this.customerSpent = customerSpent;
    }
    public int getCustomerSpent()
    {
        return customerSpent;
    }

    public int calculateStamps (int a){
        int stamps = getCustomerSpent()/50;
        return stamps;
    }




}


