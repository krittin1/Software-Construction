package test2;
import java.util.Scanner;
public class MainProgram {
        public static void main(String[] args) {
            int money;
        Scanner sc = new Scanner(System.in);
        money = sc.nextInt();
        Customer a = new Customer(money);

        //Customer function = new Customer();
        System.out.println(a.calculateStamps(money));
        //System.out.println(function.calculat)eStamps);

    }

}



