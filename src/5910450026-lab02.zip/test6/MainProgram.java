package test6;

public class MainProgram {
    public static void main (String[] args){


        MonsterBall b1 = new  MonsterBall("200","100",1,"pokeball");
        MonsterBall b2 = new MonsterBall("600","300",1.5,"greatball");
        MonsterBall b3 = new MonsterBall("1200","600",2,"ultraball");
        MonsterBall b4 = new MonsterBall("cannot be brought","cannot be sold",255,"masterball");
        System.out.println(b1.toString());
        System.out.println(b2.toString());
        System.out.println(b3.toString());
        System.out.println(b4.toString());
    }
}
