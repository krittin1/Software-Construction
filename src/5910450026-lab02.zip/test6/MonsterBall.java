package test6;

public class MonsterBall {
    private String price;
    private String sellfor;
    private double value;
    private String type;

    public MonsterBall(String price,String sellfor,double value,String type) {
        this.price = price;
        this.sellfor = sellfor;
        this.value = value;
        this.type = type;
    }

    public String getPrice() {
        return price;
    }

    public String getSellfor() {
        return sellfor;
    }

    public String getType() {

        return type;
    }

    public double getValue() {
        return value;
}


    public String toString(){
            return getType()+" "+getPrice()+" "+getSellfor()+" "+getValue();
    }

}
