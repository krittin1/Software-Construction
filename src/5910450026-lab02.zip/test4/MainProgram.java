package test4;

public class MainProgram {
    public static void main( String[] args){
        MasterMind player1 = new MasterMind();
        MasterMind player2 = new MasterMind();
        player1.setTarget("1234");
        player2.setNumber("1235");
        System.out.println(player2.calculate(player1,player2));
    }

}



